import java.util.LinkedList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement
public class Word {

	private String name;
	
	private LinkedList<Word> wordList = new LinkedList<Word>();
	  
	
	public String getName() {
		return name;
	}

	@XmlElement
	public void setName(String name) {
		this.name = name;
	}

	public LinkedList<Word> getWordList() {
		return wordList;
	}
	
	public void setWordList(LinkedList<Word> wordList) {
		this.wordList = wordList;
	}
	
	public void printWord()
	{
		System.out.println(this.getName());
	}
}
